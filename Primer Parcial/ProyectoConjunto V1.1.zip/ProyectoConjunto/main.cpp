#include <iostream>
#include <limits>
#include "ListaEnlazadaDoble.h"
#include "Persona.h"
#include "Cedula.h"

using namespace std;

bool esEntero(const string& linea);

int main() {
    ListaEnlazadaDoble* lista = new ListaEnlazadaDoble();
    int opcion;
    string linea;
    bool repite = true;
    bool repetir = true;
    string nombre1, nombre2, apellido, cedula;

    do {
        system("cls");
        cout << "***********Listas Dobles***********" << endl;
        cout << "1. Insertar" << endl;
        cout << "2. Mostrar" << endl;
        cout << "3. Guardar en archivo" << endl;
        cout << "4. Salir" << endl;
        do {
            cout << "Opcion: ";
            getline(cin, linea);

            try {
                opcion = stoi(linea);
                if (opcion > 4 || opcion < 1) {
                    cout << "Opción fuera de rango. Intente nuevamente." << endl;
                    repite = true;
                } else {
                    repite = false;
                }
            } catch (invalid_argument&) {
                cout << "No has ingresado un valor entero. Intentalo nuevamente." << endl;
                repite = true;
            } catch (out_of_range&) {
                cout << "Número demasiado grande. Intentalo nuevamente." << endl;
                repite = true;
            }
        } while (repite);

        switch (opcion) {
        case 1:
            cout << "Ingrese el primer nombre: ";
            cin >> nombre1;
            cout << "Ingrese el segundo nombre: ";
            cin >> nombre2;
            cout << "Ingrese el apellido: ";
            cin >> apellido;
            do {
                cout << "Ingrese la cedula: ";
                cin >> cedula;
                Cedula c(cedula);
                if (!c.esValida()) {
                    cout << "Cedula invalida. Intente nuevamente." << endl;
                    repetir = true;
                } else if (lista->cedulaExiste(cedula)) {
                    cout << "Cedula con ese ID ya esta creada" << endl;
                    repetir = true;
                } else {
                    repetir = false;
                }
            } while (repetir);
            lista->insertar(Persona(nombre1, nombre2, apellido, cedula));
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  
            break;
        case 2:
            lista->mostrar();
            break;
        case 3:
            lista->guardarEnArchivo();
            cout << "Datos guardados en correos.txt" << endl;
            break;
        }
        cout << "Presione enter para continuar...";
        cin.ignore(numeric_limits<streamsize>::max(), '\n');  // Limpiar el buffer de entrada
        cin.get();  // Esperar a que el usuario presione enter
    } while (opcion != 4);
    delete lista;
    return 0;
}

bool esEntero(const string& linea) {
    return !linea.empty() && all_of(linea.begin(), linea.end(), ::isdigit);
}
