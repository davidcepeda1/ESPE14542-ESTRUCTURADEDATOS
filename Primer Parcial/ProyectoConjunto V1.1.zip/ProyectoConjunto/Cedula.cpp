#include "Cedula.h"

Cedula::Cedula(const std::string& numero) : numero(numero) {}

bool Cedula::esValida() const {
    if (numero.length() != 10) return false;

    int total = 0;
    int coef[] = {2, 1, 2, 1, 2, 1, 2, 1, 2};

    for (int i = 0; i < 9; ++i) {
        int digito = numero[i] - '0';
        int mult = digito * coef[i];
        total += mult > 9 ? mult - 9 : mult;
    }

    int verificador = 10 - (total % 10);
    if (verificador == 10) verificador = 0;

    return verificador == (numero[9] - '0');
}
