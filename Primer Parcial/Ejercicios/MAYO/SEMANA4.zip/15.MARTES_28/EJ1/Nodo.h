#ifndef NODO_H
#define NODO_H

class Nodo {
public:
    int dato;
    Nodo* siguiente;
    

    Nodo(int dato);
};

#endif // NODO_H
