#include "Nodo.h"

Nodo::Nodo(int dato) : dato(dato), siguiente(nullptr) {}
