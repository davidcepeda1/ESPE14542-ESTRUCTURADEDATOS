#pragma once
#include <iostream>

class Empleado{
private:
    float sueldo;
    int static id;

};