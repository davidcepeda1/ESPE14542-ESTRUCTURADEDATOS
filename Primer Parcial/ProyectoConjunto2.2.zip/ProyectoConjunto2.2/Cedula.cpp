#include "Cedula.h"
#include <stdexcept>
#include <algorithm> // Incluir el encabezado necesario

Cedula::Cedula() : numero("") {}

void Cedula::setNumero(const std::string& num) {
    if (num.size() != 10 || !std::all_of(num.begin(), num.end(), ::isdigit)) {
        throw std::invalid_argument("La cédula debe tener 10 dígitos numéricos.");
    }
    numero = num;
}

std::string Cedula::getNumero() const {
    return numero;
}
