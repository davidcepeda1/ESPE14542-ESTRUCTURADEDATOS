#pragma once
#include <iostream>
#include <string>

class Cedula {
private:
    std::string numero;

public:
    Cedula();

    void setNumero(const std::string& num);
    std::string getNumero() const;
};
