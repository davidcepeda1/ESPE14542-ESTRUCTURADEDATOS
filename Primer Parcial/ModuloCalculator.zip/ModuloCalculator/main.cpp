#include <iostream>
#include "calculadora.h"
#include "miclasecalculadora.h"

using namespace std;

int main() {
    Calculadora* calculadora = new MiClaseCalculadora();

    int a, b;

    cout << "Ingrese el primer numero: ";
    cin >> a;

    cout << "Ingrese el segundo numero: ";
    cin >> b;

    int resultado = calculadora->calcularModulo(a, b);
    cout << "El modulo es: " << resultado << std::endl;

    delete calculadora;

    return 0;
}
