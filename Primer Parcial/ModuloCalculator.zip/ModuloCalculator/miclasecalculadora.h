#pragma once
#include "calculadora.h"

class MiClaseCalculadora : public Calculadora {
public:
    int calcularModulo(int a, int b) override;
};
