#pragma once

class Calculadora {
public:
    virtual int calcularModulo(int a, int b) = 0;
};
