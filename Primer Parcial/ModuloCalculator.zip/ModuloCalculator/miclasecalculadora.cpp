#include "miclasecalculadora.h"

int MiClaseCalculadora::calcularModulo(int a, int b) {
    if (b == 0) {
        return -1;
    }
    return a % b;
}
