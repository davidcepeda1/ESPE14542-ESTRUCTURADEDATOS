#pragma once
#include <string>

class Cesar {
public:
    std::string encriptarTexto(const std::string& texto, int cesarVariable) const;
};
